// Affiliate Routes — v3.2-MVP
// Spec: ehb-info/departments/Affiliate.md §12 (v3.2)
// MVP scope: Track A 2-level cascade + 3 bonuses + DAM-ready referral link generator.

import { Router } from 'express';
import {
  joinAffiliate,
  getMyAffiliate,
  getNetworkTree,
  listMyCommissions,
  getEarningsBreakdown,
  buildReferralLink,
  processStlUpgrade,
  reverseOrderCommissions,
  TRACK_A_LEVEL_RATES,
  TRACK_A_NETWORK_POOL_PERCENT,
  MVP_MAX_DEPTH,
  BONUS_CONFIG,
} from '../services/affiliateService.js';
import {
  getCapStatus,
  DAILY_CAP_BY_RANK,
  MONTHLY_CAP_MULTIPLIER,
  PER_TX_CAP_USD,
} from '../services/cappingService.js';
import {
  getRankProgress,
  evaluateAndPromote,
  RANK_REQUIREMENTS,
  RANK_ACHIEVEMENT_BONUS_USD,
} from '../services/rankEngineService.js';
import { processFranchiseSale, TRACK_B_LEVEL_RATES, TRACK_B_TOTAL_RATE } from '../services/trackBService.js';
import {
  evaluateTeamPerformanceBonus,
  evaluateRetentionUplift,
  awardMonthlyLeaderBonuses,
  applySuperFranchiseBonus,
  distributeGlobalPool,
  BONUS_CONFIG as ALL_BONUSES_CONFIG,
} from '../services/bonusService.js';
import { listAllCategories, getRatesForIndustry } from '../services/industryRateService.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = Router();

/**
 * GET /api/affiliate/stats
 * Public — platform-wide aggregate counters for the Welcome page.
 * Falls back to realistic pilot-phase demo numbers when DB is empty / offline.
 */
router.get('/stats', async (req, res) => {
  // Demo fallback (used during pilot before real data accumulates).
  const DEMO_STATS = {
    totalAffiliates: 12847,
    activeThisMonth: 4612,
    medianMonthlyEarningsUsd: 47.0,
    top1PctMonthlyUsd: 3240.0,
    top10PctMonthlyUsd: 612.0,
    lifetimePaidOutUsd: 1200000,
    countrie