// Affiliate Service — v3.2-MVP (Track A Product Affiliate)
//
// Spec: ehb-info/departments/Affiliate.md §12 (v3.2)
// Founder lock: 2026-04-25
//
// MVP scope (Phase 1):
//   • Track A 2-layer GoSellr commission cascade
//       Layer 1 (Seller): seller-defined 5–30% margin → 100% to direct salesperson (handled by orderService).
//       Layer 2 (Network): platform 5% of product price, hidden, split 60/30/10
//                         MVP caps cascade at L1 (3%) + L2 (1.5%) — L3 (0.5%) deferred to Phase 2.
//   • 3 bonuses:
//       - First Sale Bonus  : $5 fixed, one-time per user
//       - STL Purchase Bonus: L1 3% / L2 2% / L3 1% of upgrade payment, one-time per upgrade event
//       - Fast Sale Bonus   : 4 same-pkg sales / week → 1 free pkg, max 2 free/week
//   • Basic anti-fraud: self-purchase block, refund-aware reversal hook (orderService).
//
// NOT in MVP (Phase 2): Track B 10-level franchise cascade · 8 remaining bonuses ·
//                       Rank engine (R1–R10) · Industry categories · Dynamic pricing ·
//                       3-layer price lock · Active legs / multi-industry trackers ·
//                       Franchise activation flow · Admin flexibility config layer.

import Affiliate from '../models/Affiliate.js';
import AffiliateCommission from '../models/AffiliateCommission.js';
import User from '../models/User.js';
import Transaction from '../models/Transaction.js';
import { isConnected } from '../config/db.js';
import { logActivity } from './auditService.js';
import {
  creditAffiliateWallet,
  debitAffiliateWalletForReversal,
} from './affiliateWalletService.js';
import { applyCapAndLog } from './cappingService.js';
import { evaluateAndPromote } from './rankEngineService.js';
import { applyMatchingBonus, applyActivationBonus } from './bonusService.js';
import { getRatesForIndustry, shouldSkipTrackA } from './industryRateService.js';

// ─── v3.2-MVP CONFIG (admin-tunable in Phase 2 via affiliate_config) ─────

/** Track A network pool (5% of product price) split per spec §12.2 */
export const TRACK_A_NETWORK_POOL_PERCENT = 0.05;
export const TRACK_A_LEVEL_RATES = {
  // share of total product price (== 60% / 30% / 10% of the 5% pool)
  1: 0.03, // L1 direct upline   = 3.0%
  2: 0.015, // L2                = 1.5%
  3: 0.005, // L3 (Phase 2)      = 0.5%
};

/** MVP caps cascade depth at L2; Phase 2 will lift to L3 then full Track B 10-level. */
export const MVP_MAX_DEPTH = 2;

/** First Sale Bonus — $5 USD fixed, one-time (spec §12.7 #4) */
export const FIRST_SALE_BONUS_USD = 5;

/** STL Purchase Bonus — % of upgrade payment, one-time per upgrade (spec §12.7 #2) */
export const STL_BONUS_RATES = {
  1: 0.03, // L1 direct upline = 3%
  2: 0.02, // L2               = 2%
  3: 0.01, // L3 (Phase 2)     = 1%
};
export const STL_BONUS_MAX_DEPTH_MVP = 2; // L3 deferred to Phase 2

/** Fast Sale Bonus — 4 same-package sales/week → 1 free pkg; cap 2/week (spec §12.7 #1) */
export const FAST_SALE_TRIGGER_COUNT = 4;
export const FAST_SALE_WEEKLY_FREE_CAP = 2;

// ─── HELPERS ──────────────────────────────────────────────────────────────

/** Generate ISO week key like "2026-W17" — used for Fast Sale weekly tracker. */
export function getIsoWeekKey(date = new Date()) {
  const d = new Date(
    Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate())
  );
  // Thursday in current week determines the year per ISO 8601
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((d - yearStart) / 86_400_000 + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

/** Generate a referral code from user name + random suffix. */
function genReferralCode(name = '') {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .slice(0, 6) || 'ref';
  return `${slug}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

/** Build a public referral link for the DAM page (spec §12.3.3). */
export function buildReferralLink({ baseUrl = 'ehb.com', referralCode, productId }) {
  if (productId) return `${baseUrl}/product/${productId}?ref=${referralCode}`;
  return `${baseUrl}/ref/${referralCode}`;
}

/** Anti-fraud: block self-purchase (spec §12.13). */
function isSelfPurchase(buyerUserId, affiliateUserId) {
  if (!buyerUserId || !affiliateUserId) return false;
  return String(buyerUserId) === String(affiliateUserId);
}

// ─── PUBLIC API ───────────────────────────────────────────────────────────

/**
 * Apply to become an affiliate (or fetch existing).
 * If `referredByCode` provided, links the new user to their sponsor's chain.
 */
export async function joinAffiliate({ userId, referredByCode }) {
  if (!isConnected()) throw Object.assign(new Error('DB not connected'), { status: 503 });

  let aff = await Affiliate.findOne({ userId });
  if (aff) return aff.toObject();

  const user = await User.findById(userId);
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });

  let upstream = [];
  let referredBy = null;

  if (referredByCode) {
    const sponsor = await Affiliate.findOne({ referralCode: referredByCode });
    if (sponsor) {
      // Anti-fraud: self-referral block
      if (String(sponsor.userId) === String(userId)) {
        throw Object.assign(new Error('Self-referral not allowed'), { status: 400 });
      }
      referredBy = sponsor.userId;
      // Build upstream chain (capped at 10 for Phase 2; MVP only uses [0] and [1])
      upstream = [sponsor.userId, ...(sponsor.upstream || []).slice(0, 9)];

      await Affiliate.updateOne(
        { _id: sponsor._id },
        { $inc: { 'stats.directReferrals': 1, 'stats.networkSize': 1 } }
      );
      if (upstream.length > 1) {
        await Affiliate.updateMany(
          { userId: { $in: upstream.slice(1) } },
          { $inc: { 'stats.networkSize': 1 } }
        );
      }
    }
  }

  aff = await Affiliate.create({
    userId,
    referralCode: genReferralCode(user.name || user.email),
    referredBy,
    upstream,
    rank: 'R1',
    eligible: (user.stl?.level || 1) >= 1,
    activatedAt: new Date(),
    productAffiliateEnabled: true,
  });

  await logActivity({
    actorUserId: userId,
    action: 'affiliate.joined',
    target: 'affiliate',
    targetId: aff._id.toString(),
    after: { code: aff.referralCode, hasSponsor: Boolean(referredBy) },
  });

  return aff.toObject();
}

export async function getMyAffiliate(userId) {
  if (!isConnected()) return null;
  return Affiliate.findOne({ userId }).lean();
}

/**
 * Get full network tree under a user.
 * MVP caps at depth 2 (L1 + L2). Phase 2 will lift to 10.
 */
export async function getNetworkTree(userId, maxDepth = MVP_MAX_DEPTH) {
  if (!isConnected()) return { levels: [] };
  const depth = Math.min(maxDepth, 10);
  const levels = [];
  let current = [userId];

  for (let d = 1; d <= depth && current.length > 0; d++) {
    const next = await Affiliate.find({ referredBy: { $in: current } })
      .populate('userId', 'name email stl')
      .lean();
    if (!next.length) break;
    levels.push({
      level: d,
      count: next.length,
      members: next.map((m) => ({
        userId: m.userId?._id || m.userId,
        name: m.userId?.name || 'Unknown',
        stlLevel: m.userId?.stl?.level || 1,
        rank: m.rank || 'R1',
        code: m.referralCode,
        joinedAt: m.createdAt,
   