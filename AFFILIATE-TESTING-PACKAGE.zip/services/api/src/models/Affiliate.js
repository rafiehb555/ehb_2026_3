import mongoose from 'mongoose';

/**
 * EHB Affiliate Model — v3.2-MVP (Track A Product Affiliate)
 *
 * Spec: ehb-info/departments/Affiliate.md §12 (v3.2)
 * Founder lock: 2026-04-25
 *
 * MVP scope (Phase 1):
 *   - Track A: 2-level commission cascade (L1 10%, L2 5% — applied per industry category)
 *     For DAM products with no industry tag: defaults to Standard category (10%/5%/2%)
 *     Latest founder rule: Track A network 5% of product price split 60/30/10 → L1 3% / L2 1.5% / L3 0.5%
 *     MVP simplification: cap at 2 levels (L1 + L2) until Phase 2.
 *   - 3 bonuses: First Sale ($5 fixed), STL Purchase (3%/2%/1%), Fast Sale (4 sales/week → 1 free pkg, cap 2/week)
 *
 * Phase 2 will add: R1–R10 rank computation, Track B 10-level cascade,
 *                  remaining 8 bonuses, dynamic pricing, 3-layer price lock,
 *                  active legs, multi-industry trackers, franchise activation flow.
 */

const FastSaleTrackerSchema = new mongoose.Schema(
  {
    /** ISO week key, e.g. "2026-W17" — auto-resets when week changes */
    weekKey: { type: String, default: '' },
    /** Map of productId → sales count this week */
    sameProductSales: { type: Map, of: Number, default: () => new Map() },
    /** How many free packages already awarded this week (cap = 2 pe