import mongoose from 'mongoose';

/**
 * EHB Affiliate Commission Model — v3.2-MVP
 *
 * Spec: ehb-info/departments/Affiliate.md §12 (v3.2)
 *
 * MVP commission types (Phase 1):
 *   direct        — Track A direct sale (L1 of network 5% pool = 3% of product price)
 *   level         — Track A L2 (1.5% of product price; level field = 2)
 *   first_sale    — First Sale Bonus ($5 fixed, one-time per user)
 *   stl_purchase  — STL Upgrade Purchase Bonus (3%/2%/1% one-time on referral upgrade)
 *   fast_sale     — Fast Sale Bonus (free package reward; amountUsd = package value)
 *
 * Phase 2 types (declared in enum for forward compat, not written in MVP):
 *   matching · rank_achievement · team_performance · retention ·
 *   monthly_leader · super_franchise · global_pool · franchise_cascade
 *
 * v1.0 legacy types kept for backward compat: pool · franchise · product
 */

const AffiliateCommissionSchema = new mongoose.Schema(
  {
    earnerUserId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    sourceUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', inde